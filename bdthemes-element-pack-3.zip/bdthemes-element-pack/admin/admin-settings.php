<?php

namespace ElementPack\Admin;

use Elementor\Modules\Usage\Module;
use Elementor\Tracker;
use ElementPack\Admin\ModuleService;
use ElementPack\Base\Element_Pack_Base;
use ElementPack\Notices;
use ElementPack\Utils;

/**
 * Element Pack Admin Settings Class
 */

class ElementPack_Admin_Settings {

	public static $modules_list;
	public static $modules_names;

	public static $modules_list_only_widgets;
	public static $modules_names_only_widgets;

	public static $modules_list_only_3rdparty;
	public static $modules_names_only_3rdparty;
	public $license_title;

	const PAGE_ID = 'element_pack_options';

	private $settings_api;

	public $responseObj;
	public $licenseMessage;
	public $showMessage = false;
	private $is_activated = false;

	public function __construct() {

		$this->settings_api = new ElementPack_Settings_API;

		$license_key   = self::get_license_key();
		$license_email = self::get_license_email();

		Element_Pack_Base::add_on_delete(
			function () {
				update_option( 'element_pack_license_email', '' );
				update_option( 'element_pack_license_key', '' );
				update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), '' );
			}
		);

		/**
		 * Mini-Cart issue fixed
		 * Check if MiniCart activate in EP and Elementor
		 * If both is activated then Show Notice
		 */

		$ep_3rdPartyOption = get_option( 'element_pack_third_party_widget' );

		$el_use_mini_cart = get_option( 'elementor_use_mini_cart_template' );

		if ( $el_use_mini_cart !== false && $ep_3rdPartyOption !== false ) {
			if ( $ep_3rdPartyOption ) {
				if ( 'yes' == $el_use_mini_cart && isset( $ep_3rdPartyOption['wc-mini-cart'] ) && 'off' !== trim( $ep_3rdPartyOption['wc-mini-cart'] ) ) {
					add_action( 'admin_notices', [ $this, 'el_use_mini_cart' ], 10, 3 );
				}
			}
		}

		if ( Element_Pack_Base::check_wp_plugin( $license_key, $license_email, $error, $responseObj, BDTEP__FILE__ ) ) {

			add_action( 'admin_post_element_pack_deactivate_license', [ $this, 'action_deactivate_license' ] );
			$this->is_activated = true;
		} else {
			if ( ! empty( $licenseKey ) && ! empty( $this->licenseMessage ) ) {
				$this->showMessage = true;
			}

			//echo $error;
			if ( $error ) {
				$this->licenseMessage = $error;
				add_action( 'admin_notices', [ $this, 'license_activate_error_notice' ], 10, 3 );
			}

			add_action( 'admin_notices', [ $this, 'license_activate_notice' ] );

			update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), "" );
			add_action( 'admin_post_element_pack_activate_license', [ $this, 'action_activate_license' ] );
		}

		$license_info = Element_Pack_Base::get_register_info();
		$title_info   = isset( $license_info->license_title ) && ! empty( $license_info->license_title ) && $license_info->license_title ? $license_info->license_title : 'None';

		$this->license_title = $title_info;
		$this->license_wl_process();

		if ( ! defined( 'BDTEP_HIDE' ) || false == self::license_wl_status() ) {
			add_action( 'admin_init', [ $this, 'admin_init' ] );
			add_action( 'admin_menu', [ $this, 'admin_menu' ], 201 );
			add_action( 'admin_menu', [ $this, 'admin_license_menu' ], 202 );
		}
	}

	public function license_wl_process() {
		$license_title = $this->license_title;
		$title_arr     = explode( ' ', strtolower( $license_title ) );
		$titles        = array_map( 'md5', $title_arr );

		$agency   = in_array( '1d1d5778763061ebb2bdc5db696077a6', $titles );
		$extended = in_array( 'd3e78e3d3b68cb0fbd9f66dcaef93cea', $titles );

		$status = false;

		if ( $agency || $extended ) {
			$status = true;
		}

		update_option( 'element_pack_license_title_status', $status );
	}

	public static function license_wl_status() {
		$status = get_option( 'element_pack_license_title_status' );

		if ( $status ) {
			return true;
		}

		return false;
	}
	/**
	 * Get used widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */
	public static function get_used_widgets() {

		$used_widgets = array();

		if ( ! Tracker::is_allow_track() ) {
			return $used_widgets;
		}

		if ( class_exists( 'Elementor\Modules\Usage\Module' ) ) {

			$module     = Module::instance();
			$elements   = $module->get_formatted_usage( 'raw' );
			$ep_widgets = self::get_ep_widgets_names();

			if ( is_array( $elements ) || is_object( $elements ) ) {
				foreach ( $elements as $post_type => $data ) {
					foreach ( $data['elements'] as $element => $count ) {
						if ( in_array( $element, $ep_widgets, true ) ) {
							if ( isset( $used_widgets[ $element ] ) ) {
								$used_widgets[ $element ] += $count;
							} else {
								$used_widgets[ $element ] = $count;
							}
						}
					}
				}
			}
		}
		return $used_widgets;
	}

	/**
	 * Get used separate widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_used_only_widgets() {

		$used_widgets = array();

		if ( ! Tracker::is_allow_track() ) {
			return $used_widgets;
		}

		if ( class_exists( 'Elementor\Modules\Usage\Module' ) ) {

			$module     = Module::instance();
			$elements   = $module->get_formatted_usage( 'raw' );
			$ep_widgets = self::get_ep_only_widgets();

			if ( is_array( $elements ) || is_object( $elements ) ) {

				foreach ( $elements as $post_type => $data ) {
					foreach ( $data['elements'] as $element => $count ) {
						if ( in_array( $element, $ep_widgets, true ) ) {
							if ( isset( $used_widgets[ $element ] ) ) {
								$used_widgets[ $element ] += $count;
							} else {
								$used_widgets[ $element ] = $count;
							}
						}
					}
				}
			}
		}

		return $used_widgets;
	}

	/**
	 * Get used only separate 3rdParty widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_used_only_3rdparty() {

		$used_widgets = array();

		if ( ! Tracker::is_allow_track() ) {
			return $used_widgets;
		}

		if ( class_exists( 'Elementor\Modules\Usage\Module' ) ) {

			$module     = Module::instance();
			$elements   = $module->get_formatted_usage( 'raw' );
			$ep_widgets = self::get_ep_only_3rdparty_names();

			if ( is_array( $elements ) || is_object( $elements ) ) {

				foreach ( $elements as $post_type => $data ) {
					foreach ( $data['elements'] as $element => $count ) {
						if ( in_array( $element, $ep_widgets, true ) ) {
							if ( isset( $used_widgets[ $element ] ) ) {
								$used_widgets[ $element ] += $count;
							} else {
								$used_widgets[ $element ] = $count;
							}
						}
					}
				}
			}
		}

		return $used_widgets;
	}

	/**
	 * Get unused widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_unused_widgets() {

		if ( ! current_user_can( 'manage_options' ) ) {
			die();
		}

		$ep_widgets = self::get_ep_widgets_names();

		$used_widgets = self::get_used_widgets();

		$unused_widgets = array_diff( $ep_widgets, array_keys( $used_widgets ) );

		return $unused_widgets;
	}

	/**
	 * Get unused separate widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_unused_only_widgets() {

		if ( ! current_user_can( 'manage_options' ) ) {
			die();
		}

		$ep_widgets = self::get_ep_only_widgets();

		$used_widgets = self::get_used_only_widgets();

		$unused_widgets = array_diff( $ep_widgets, array_keys( $used_widgets ) );

		return $unused_widgets;
	}

	/**
	 * Get unused separate 3rdparty widgets.
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_unused_only_3rdparty() {

		if ( ! current_user_can( 'manage_options' ) ) {
			die();
		}

		$ep_widgets = self::get_ep_only_3rdparty_names();

		$used_widgets = self::get_used_only_3rdparty();

		$unused_widgets = array_diff( $ep_widgets, array_keys( $used_widgets ) );

		return $unused_widgets;
	}

	/**
	 * Get widgets name
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_ep_widgets_names() {
		$names = self::$modules_names;

		if ( null === $names ) {
			$names = array_map(
				function ($item) {
					return isset( $item['name'] ) ? 'bdt-' . str_replace( '_', '-', $item['name'] ) : 'none';
				},
				self::$modules_list
			);
		}

		return $names;
	}

	/**
	 * Get separate widgets name
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_ep_only_widgets() {
		$names = self::$modules_names_only_widgets;

		if ( null === $names ) {
			$names = array_map(
				function ($item) {
					return isset( $item['name'] ) ? 'bdt-' . str_replace( '_', '-', $item['name'] ) : 'none';
				},
				self::$modules_list_only_widgets
			);
		}

		return $names;
	}

	/**
	 * Get separate 3rdParty widgets name
	 *
	 * @access public
	 * @return array
	 * @since 6.0.0
	 *
	 */

	public static function get_ep_only_3rdparty_names() {
		$names = self::$modules_names_only_3rdparty;

		if ( null === $names ) {
			$names = array_map(
				function ($item) {
					return isset( $item['name'] ) ? 'bdt-' . str_replace( '_', '-', $item['name'] ) : 'none';
				},
				self::$modules_list_only_3rdparty
			);
		}

		return $names;
	}

	/**
	 * Get URL with page id
	 *
	 * @access public
	 *
	 */

	public static function get_url() {
		return admin_url( 'admin.php?page=' . self::PAGE_ID );
	}

	/**
	 * Init settings API
	 *
	 * @access public
	 *
	 */

	public function admin_init() {

		//set the settings
		$this->settings_api->set_sections( $this->get_settings_sections() );
		$this->settings_api->set_fields( $this->element_pack_admin_settings() );

		//initialize settings
		$this->settings_api->admin_init();
	}

	/**
	 * Add Plugin Menus
	 *
	 * @access public
	 *
	 */

	public function admin_menu() {
		add_menu_page(
			BDTEP_TITLE . ' ' . esc_html__( 'Dashboard', 'bdthemes-element-pack' ),
			BDTEP_TITLE,
			'manage_options',
			self::PAGE_ID,
			[ $this, 'plugin_page' ],
			$this->element_pack_icon(),
			58
		);

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( 'Core Widgets', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_active_modules',
			[ $this, 'display_page' ]
		);

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( '3rd Party Widgets', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_third_party_widget',
			[ $this, 'display_page' ]
		);

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( 'Extensions', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_elementor_extend',
			[ $this, 'display_page' ]
		);

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( 'API Settings', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_api_settings',
			[ $this, 'display_page' ]
		);

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( 'Other Settings', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_other_settings',
			[ $this, 'display_page' ]
		);

		/**
		 * Wincher Implementation
		 */
		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( 'SEO Performance', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '#element_pack_seo_performance',
			[ $this, 'display_page' ]
		);
		/**
		 * /Wincher Implementation
		 */
	}

	public function admin_license_menu() {

		if ( ! defined( 'BDTEP_LO' ) || false == self::license_wl_status() ) {
			add_submenu_page(
				self::PAGE_ID,
				BDTEP_TITLE,
				esc_html__( 'License', 'bdthemes-element-pack' ),
				'manage_options',
				self::PAGE_ID . '#element_pack_license_settings',
				[ $this, 'display_page' ]
			);
		}
	}

	/**
	 * Get SVG Icons of Element Pack
	 *
	 * @access public
	 * @return string
	 */

	public function element_pack_icon() {
		return 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyMy4wLjIsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHdpZHRoPSIyMzAuN3B4IiBoZWlnaHQ9IjI1NC44MXB4IiB2aWV3Qm94PSIwIDAgMjMwLjcgMjU0LjgxIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAyMzAuNyAyNTQuODE7Ig0KCSB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+DQoJLnN0MHtmaWxsOiNGRkZGRkY7fQ0KPC9zdHlsZT4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik02MS4wOSwyMjkuMThIMjguOTVjLTMuMTcsMC01Ljc1LTIuNTctNS43NS01Ljc1bDAtMTkyLjA3YzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDMyLjE0DQoJYzMuMTcsMCw1Ljc1LDIuNTcsNS43NSw1Ljc1djE5Mi4wN0M2Ni44MywyMjYuNjEsNjQuMjYsMjI5LjE4LDYxLjA5LDIyOS4xOHoiLz4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0yMDcuNSwzMS4zN3YzMi4xNGMwLDMuMTctMi41Nyw1Ljc1LTUuNzUsNS43NUg5MC4wNGMtMy4xNywwLTUuNzUtMi41Ny01Ljc1LTUuNzVWMzEuMzcNCgljMC0zLjE3LDIuNTctNS43NSw1Ljc1LTUuNzVoMTExLjcyQzIwNC45MywyNS42MiwyMDcuNSwyOC4yLDIwNy41LDMxLjM3eiIvPg0KPHBhdGggY2xhc3M9InN0MCIgZD0iTTIwNy41LDExMS4zM3YzMi4xNGMwLDMuMTctMi41Nyw1Ljc1LTUuNzUsNS43NUg5MC4wNGMtMy4xNywwLTUuNzUtMi41Ny01Ljc1LTUuNzV2LTMyLjE0DQoJYzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDExMS43MkMyMDQuOTMsMTA1LjU5LDIwNy41LDEwOC4xNiwyMDcuNSwxMTEuMzN6Ii8+DQo8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMjA3LjUsMTkxLjN2MzIuMTRjMCwzLjE3LTIuNTcsNS43NS01Ljc1LDUuNzVIOTAuMDRjLTMuMTcsMC01Ljc1LTIuNTctNS43NS01Ljc1VjE5MS4zDQoJYzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDExMS43MkMyMDQuOTMsMTg1LjU1LDIwNy41LDE4OC4xMywyMDcuNSwxOTEuM3oiLz4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xNjkuNjIsMjUuNjJoMzIuMTRjMy4xNywwLDUuNzUsMi41Nyw1Ljc1LDUuNzV2MTEyLjFjMCwzLjE3LTIuNTcsNS43NS01Ljc1LDUuNzVoLTMyLjE0DQoJYy0zLjE3LDAtNS43NS0yLjU3LTUuNzUtNS43NVYzMS4zN0MxNjMuODcsMjguMiwxNjYuNDQsMjUuNjIsMTY5LjYyLDI1LjYyeiIvPg0KPC9zdmc+DQo=';
	}

	/**
	 * Get SVG Icons of Element Pack
	 *
	 * @access public
	 * @return array
	 */

	public function get_settings_sections() {
		$sections = [ 
			[ 
				'id'    => 'element_pack_active_modules',
				'title' => esc_html__( 'Core Widgets', 'bdthemes-element-pack' ),
			],
			[ 
				'id'    => 'element_pack_third_party_widget',
				'title' => esc_html__( '3rd Party Widgets', 'bdthemes-element-pack' ),
			],
			[ 
				'id'    => 'element_pack_elementor_extend',
				'title' => esc_html__( 'Extensions', 'bdthemes-element-pack' ),
			],
			[ 
				'id'    => 'element_pack_api_settings',
				'title' => esc_html__( 'API Settings', 'bdthemes-element-pack' ),
			],
			[ 
				'id'    => 'element_pack_other_settings',
				'title' => esc_html__( 'Other Settings', 'bdthemes-element-pack' ),
			],
		];

		return $sections;
	}

	/**
	 * Merge Admin Settings
	 *
	 * @access protected
	 * @return array
	 */

	protected function element_pack_admin_settings() {
		return ModuleService::get_widget_settings( function ($settings) {
			$settings_fields = $settings['settings_fields'];

			self::$modules_list               = array_merge( $settings_fields['element_pack_active_modules'], $settings_fields['element_pack_third_party_widget'] );
			self::$modules_list_only_widgets  = $settings_fields['element_pack_active_modules'];
			self::$modules_list_only_3rdparty = $settings_fields['element_pack_third_party_widget'];

			return $settings_fields;
		} );
	}

	/**
	 * Get Welcome Panel
	 *
	 * @access public
	 * @return void
	 */

	public function element_pack_welcome() {
		$track_nw_msg = '';
		if ( ! Tracker::is_allow_track() ) {
			$track_nw     = esc_html__( 'This feature is not working because the Elementor Usage Data Sharing feature is Not Enabled.', 'bdthemes-element-pack' );
			$track_nw_msg = 'bdt-tooltip="' . $track_nw . '"';
		}
		?>

		<div class="ep-dashboard-panel"
			bdt-scrollspy="target: > div > div > .bdt-card; cls: bdt-animation-slide-bottom-small; delay: 300">

			<div class="bdt-grid" bdt-grid bdt-height-match="target: > div > .bdt-card">
				<div class="bdt-width-1-2@m bdt-width-1-4@l">
					<div class="ep-widget-status bdt-card bdt-card-body" <?php echo wp_kses_post( $track_nw_msg ); ?>>

						<?php
						$used_widgets    = count( self::get_used_widgets() );
						$un_used_widgets = count( self::get_unused_widgets() );
						?>

						<div class="ep-count-canvas-wrap bdt-flex bdt-flex-between">
							<div class="ep-count-wrap">
								<h1 class="ep-feature-title"><?php esc_html_e( 'All Widgets', 'bdthemes-element-pack' ); ?></h1>
								<div class="ep-widget-count"><?php esc_html_e( 'Used:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $used_widgets ); ?>
									</b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Unused:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $un_used_widgets ); ?>
									</b>
								</div>
								<div class="ep-widget-count"><?php esc_html_e( 'Total:', 'bdthemes-element-pack' ); ?>
									<b>
										<?php echo esc_html( $used_widgets + $un_used_widgets ); ?>
									</b>
								</div>
							</div>

							<div class="ep-canvas-wrap">
								<canvas id="bdt-db-total-status" style="height: 120px; width: 120px;"
									data-label="Total Widgets Status - (<?php echo esc_html( $used_widgets + $un_used_widgets ); ?>)"
									data-labels="<?php echo esc_attr( 'Used, Unused' ); ?>"
									data-value="<?php echo esc_attr( $used_widgets ) . ',' . esc_attr( $un_used_widgets ); ?>"
									data-bg="#FFD166, #fff4d9" data-bg-hover="#0673e1, #e71522"></canvas>
							</div>
						</div>

					</div>
				</div>
				<div class="bdt-width-1-2@m bdt-width-1-4@l">
					<div class="ep-widget-status bdt-card bdt-card-body" <?php echo wp_kses_post( $track_nw_msg ); ?>>

						<?php
						$used_only_widgets   = count( self::get_used_only_widgets() );
						$unused_only_widgets = count( self::get_unused_only_widgets() );
						?>


						<div class="ep-count-canvas-wrap bdt-flex bdt-flex-between">
							<div class="ep-count-wrap">
								<h1 class="ep-feature-title"><?php esc_html_e( 'Core', 'bdthemes-element-pack' ); ?></h1>
								<div class="ep-widget-count"><?php esc_html_e( 'Used:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $used_only_widgets ); ?>
									</b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Unused:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $unused_only_widgets ); ?>
									</b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Total:', 'bdthemes-element-pack' ); ?>
									<b>
										<?php echo esc_html( $used_only_widgets + $unused_only_widgets ); ?>
									</b>
								</div>
							</div>

							<div class="ep-canvas-wrap">
								<canvas id="bdt-db-only-widget-status" style="height: 120px; width: 120px;"
									data-label="Core Widgets Status - (<?php echo esc_html( $used_only_widgets + $unused_only_widgets ); ?>)"
									data-labels="<?php echo esc_attr( 'Used, Unused' ); ?>"
									data-value="<?php echo esc_attr( $used_only_widgets ) . ',' . esc_attr( $unused_only_widgets ); ?>"
									data-bg="#EF476F, #ffcdd9" data-bg-hover="#0673e1, #e71522"></canvas>
							</div>
						</div>

					</div>
				</div>
				<div class="bdt-width-1-2@m bdt-width-1-4@l">
					<div class="ep-widget-status bdt-card bdt-card-body" <?php echo wp_kses_post( $track_nw_msg ); ?>>

						<?php
						$used_only_3rdparty   = count( self::get_used_only_3rdparty() );
						$unused_only_3rdparty = count( self::get_unused_only_3rdparty() );
						?>


						<div class="ep-count-canvas-wrap bdt-flex bdt-flex-between">
							<div class="ep-count-wrap">
								<h1 class="ep-feature-title"><?php esc_html_e( '3rd Party', 'bdthemes-element-pack' ); ?></h1>
								<div class="ep-widget-count"><?php esc_html_e( 'Used:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $used_only_3rdparty ); ?>
									</b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Unused:', 'bdthemes-element-pack' ); ?> <b>
										<?php echo esc_html( $unused_only_3rdparty ); ?>
									</b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Total:', 'bdthemes-element-pack' ); ?>
									<b>
										<?php echo esc_html( $used_only_3rdparty + $unused_only_3rdparty ); ?>
									</b>
								</div>
							</div>

							<div class="ep-canvas-wrap">
								<canvas id="bdt-db-only-3rdparty-status" style="height: 120px; width: 120px;"
									data-label="3rd Party Widgets Status - (<?php echo esc_html( $used_only_3rdparty + $unused_only_3rdparty ); ?>)"
									data-labels="<?php echo esc_attr( 'Used, Unused' ); ?>"
									data-value="<?php echo esc_attr( $used_only_3rdparty ) . ',' . esc_attr( $unused_only_3rdparty ); ?>"
									data-bg="#06D6A0, #B6FFEC" data-bg-hover="#0673e1, #e71522"></canvas>
							</div>
						</div>

					</div>
				</div>

				<div class="bdt-width-1-2@m bdt-width-1-4@l">
					<div class="ep-widget-status bdt-card bdt-card-body" <?php echo wp_kses_post( $track_nw_msg ); ?>>

						<div class="ep-count-canvas-wrap bdt-flex bdt-flex-between">
							<div class="ep-count-wrap">
								<h1 class="ep-feature-title"><?php esc_html_e( 'Active', 'bdthemes-element-pack' ); ?></h1>
								<div class="ep-widget-count"><?php esc_html_e( 'Core:', 'bdthemes-element-pack' ); ?> <b
										id="bdt-total-widgets-status-core"></b></div>
								<div class="ep-widget-count"><?php esc_html_e( '3rd Party:', 'bdthemes-element-pack' ); ?> <b
										id="bdt-total-widgets-status-3rd"></b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Extensions:', 'bdthemes-element-pack' ); ?> <b
										id="bdt-total-widgets-status-extensions"></b></div>
								<div class="ep-widget-count"><?php esc_html_e( 'Total:', 'bdthemes-element-pack' ); ?> <b
										id="bdt-total-widgets-status-heading"></b></div>
							</div>

							<div class="ep-canvas-wrap">
								<canvas id="bdt-total-widgets-status" style="height: 120px; width: 120px;"
									data-label="Total Active Widgets Status"
									data-labels="<?php echo esc_attr( 'Core, 3rd Party, Extensions' ); ?>"
									data-bg="#0680d6, #B0EBFF, #E6F9FF" data-bg-hover="#0673e1, #B0EBFF, #b6f9e8">
								</canvas>
							</div>
						</div>

					</div>
				</div>
			</div>

			<?php if ( ! Tracker::is_allow_track() ) : ?>
				<div class="bdt-border-rounded bdt-box-shadow-small bdt-alert-warning" bdt-alert>
					<a href class="bdt-alert-close" bdt-close></a>
					<div class="bdt-text-default">
						<?php
						esc_html_e( 'To view widgets analytics, Elementor Usage Data Sharing feature by Elementor needs to be activated. Please activate the feature to get widget analytics instantly ', 'bdthemes-element-pack' );
						echo '<a href="' . esc_url( admin_url( 'admin.php?page=elementor' ) ) . '">from here.</a>';
						?>
					</div>
				</div>
			<?php endif; ?>

			<div class="bdt-grid" bdt-grid bdt-height-match="target: > div > .bdt-card">
				<div class="bdt-width-1-3@m ep-support-section">
					<div class="ep-support-content bdt-card bdt-card-body">
						<h1 class="ep-feature-title"><?php esc_html_e( 'Support And Feedback', 'bdthemes-element-pack' ); ?>
						</h1>
						<p><?php _e( 'Feeling like to consult with an expert? Take live Chat support immediately from', 'bdthemes-element-pack' ); ?>
							<a href="https://elementpack.pro" target="_blank"
								rel=""><?php _e( 'ElementPack', 'bdthemes-element-pack' ); ?></a>.
							<?php _e( 'We are always ready to help you 24/7.', 'bdthemes-element-pack' ); ?>
						</p>
						<p><strong><?php _e( 'Or if you’re facing technical issues with our plugin, then please create a support ticket', 'bdthemes-element-pack' ); ?></strong>
						</p>
						<a class="bdt-button bdt-btn-blue bdt-margin-small-top bdt-margin-small-right" target="_blank" rel=""
							href="https://bdthemes.com/all-knowledge-base-of-bdthemes-element-pack/"><?php _e( 'Knowledge Base', 'bdthemes-element-pack' ); ?></a>
						<a class="bdt-button bdt-btn-grey bdt-margin-small-top" target="_blank"
							href="https://bdthemes.com/support/"><?php _e( 'Get Support', 'bdthemes-element-pack' ); ?></a>
					</div>
				</div>

				<div class="bdt-width-2-3@m">
					<div class="bdt-card bdt-card-body ep-system-requirement">
						<h1 class="ep-feature-title bdt-margin-small-bottom">
							<?php esc_html_e( 'System Requirement', 'bdthemes-element-pack' ); ?>
						</h1>
						<?php $this->element_pack_system_requirement(); ?>
					</div>
				</div>
			</div>

			<div class="bdt-grid" bdt-grid bdt-height-match="target: > div > .bdt-card">
				<div class="bdt-width-1-2@m ep-support-section">
					<div class="bdt-card bdt-card-body ep-feedback-bg">
						<h1 class="ep-feature-title"><?php _e( 'Missing Any Feature?', 'bdthemes-element-pack' ); ?></h1>
						<p style="max-width: 520px;">
							<?php _e( 'Are you in need of a feature that’s not available in our plugin? Feel free to do a feature request from here,', 'bdthemes-element-pack' ); ?>
						</p>
						<a class="bdt-button bdt-btn-grey bdt-margin-small-top" target="_blank" rel=""
							href="https://feedback.elementpack.pro/b/3v2gg80n/feature-requests/idea/new"><?php _e( 'Request Feature', 'bdthemes-element-pack' ); ?></a>
					</div>
				</div>

				<div class="bdt-width-1-2@m">
					<div class="bdt-card bdt-card-body ep-tryaddon-bg">
						<h1 class="ep-feature-title"><?php _e( 'Try Our Other Plugins', 'bdthemes-element-pack' ); ?></h1>
						<p style="max-width: 520px;">
							<?php echo esc_html__('Prime Slider, Ultimate Post Kit, Ultimate Store Kit, Pixel Gallery & Live Copy Paste addons for Elementor is the best slider, blogs and eCommerce plugin for WordPress. Also, try our new plugin ZoloBlocks for Gutenberg.', 'ultimate-store-kit'); ?>
						</p>
						<div class="bdt-others-plugins-link">
							<a class="bdt-button bdt-btn-ps bdt-margin-small-right" target="_blank"
								href="https://wordpress.org/plugins/bdthemes-prime-slider-lite/"
								bdt-tooltip="<?php esc_attr_e( 'The revolutionary slider builder addon for Elementor with next-gen superb interface. It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'Prime Slider', 'bdthemes-element-pack' ); ?>
							</a>
							<a class="bdt-button bdt-btn-zb bdt-margin-small-right" target="_blank"
								href="https://wordpress.org/plugins/zoloblocks/"
								bdt-tooltip="<?php esc_attr_e( 'ZoloBlocks is a collection of blocks for the new WordPress block editor (Gutenberg). It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'ZoloBlocks', 'bdthemes-element-pack' ); ?>
							</a>
							<a class="bdt-button bdt-btn-upk bdt-margin-small-right" target="_blank" rel=""
								href="https://wordpress.org/plugins/ultimate-post-kit/"
								bdt-tooltip="<?php esc_attr_e( 'Best blogging addon for building quality blogging website with fine-tuned features and widgets. It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'Ultimate Post Kit', 'bdthemes-element-pack' ); ?>
							</a>
							<a class="bdt-button bdt-btn-usk bdt-margin-small-right" target="_blank" rel=""
								href="https://wordpress.org/plugins/ultimate-store-kit/"
								bdt-tooltip="<?php esc_attr_e( 'The only eCommmerce addon for answering all your online store design problems in one package. It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'Ultimate Store Kit', 'bdthemes-element-pack' ); ?>
							</a>
							<a class="bdt-button bdt-btn-live-copy bdt-margin-small-right" target="_blank" rel=""
								href="https://wordpress.org/plugins/live-copy-paste/"
								bdt-tooltip="<?php esc_attr_e( 'Superfast cross-domain copy-paste mechanism for WordPress websites with true UI copy experience. It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'Live Copy Paste', 'bdthemes-element-pack' ); ?>
							</a>
							<a class="bdt-button bdt-btn-pg bdt-margin-small-right" target="_blank"
								href="https://wordpress.org/plugins/pixel-gallery/"
								bdt-tooltip="<?php esc_attr_e( 'Pixel Gallery provides more than 30+ essential elements for everyday applications to simplify the whole web building process. It\'s Free! Download it.', 'bdthemes-element-pack' ); ?>">
								<?php _e( 'Pixel Gallery', 'bdthemes-element-pack' ); ?>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>


		<?php
	}

	/**
	 * Get License Key
	 *
	 * @access public
	 * @return string
	 */

	public static function get_license_key() {
		$license_key = get_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ) );
		if ( empty( $license_key ) ) {
			$license_key = get_option( 'element_pack_license_key' );
			if ( ! empty( $license_key ) ) {
				self::set_license_key( $license_key );
				update_option( 'element_pack_license_key', '' );
			}
		}
		return trim( $license_key );
	}

	/**
	 * Get License Email
	 *
	 * @access public
	 * @return string
	 */

	public static function get_license_email() {
		return trim( get_option( 'element_pack_license_email', get_bloginfo( 'admin_email' ) ) );
	}

	/**
	 * Set License Key
	 *
	 * @access public
	 * @return string
	 */

	public static function set_license_key( $license_key ) {

		return update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), $license_key );
	}

	/**
	 * Set License Email
	 *
	 * @access public
	 * @return string
	 */

	public static function set_license_email( $license_email ) {
		return update_option( 'element_pack_license_email', $license_email );
	}

	/**
	 * Display License Page
	 *
	 * @access public
	 */

	public function license_page() {

		if ( $this->is_activated ) {

			$this->license_activated();
		} else {
			if ( ! empty( $licenseKey ) && ! empty( $this->licenseMessage ) ) {
				$this->showMessage = true;
			}

			$this->license_form();
		}
	}

	/**
	 * Display System Requirement
	 *
	 * @access public
	 * @return void
	 */

	public function element_pack_system_requirement() {
		$php_version        = phpversion();
		$max_execution_time = ini_get( 'max_execution_time' );
		$memory_limit       = ini_get( 'memory_limit' );
		$post_limit         = ini_get( 'post_max_size' );
		$uploads            = wp_upload_dir();
		$upload_path        = $uploads['basedir'];
		$yes_icon           = '<span class="valid"><i class="dashicons-before dashicons-yes"></i></span>';
		$no_icon            = '<span class="invalid"><i class="dashicons-before dashicons-no-alt"></i></span>';

		$environment = Utils::get_environment_info();

		?>
		<ul class="check-system-status bdt-grid bdt-child-width-1-2@m bdt-grid-small ">
			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'PHP Version:', 'bdthemes-element-pack' ); ?></span>

					<?php
					if ( version_compare( $php_version, '7.4.0', '<' ) ) {
						echo wp_kses_post( $no_icon );
						echo '<span class="label2" title="' . esc_attr__( 'Min: 7.4 Recommended', 'bdthemes-element-pack' ) . '" bdt-tooltip>' . esc_html__( 'Currently:', 'bdthemes-element-pack' ) . ' ' . esc_html( $php_version ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">' . esc_html__( 'Currently:', 'bdthemes-element-pack' ) . ' ' . esc_html( $php_version ) . '</span>';
					}
					?>
				</div>

			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'Max execution time:', 'bdthemes-element-pack' ); ?> </span>
					<?php
					if ( $max_execution_time < '90' ) {
						echo wp_kses_post( $no_icon );
						echo '<span class="label2" title="Min: 90 Recommended" bdt-tooltip>Currently: ' . esc_html( $max_execution_time ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">Currently: ' . esc_html( $max_execution_time ) . '</span>';
					}
					?>
				</div>
			</li>
			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'Memory Limit:', 'bdthemes-element-pack' ); ?> </span>

					<?php
					if ( intval( $memory_limit ) < '512' ) {
						echo wp_kses_post( $no_icon );
						echo '<span class="label2" title="Min: 512M Recommended" bdt-tooltip>Currently: ' . esc_html( $memory_limit ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">Currently: ' . esc_html( $memory_limit ) . '</span>';
					}
					?>
				</div>
			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'Max Post Limit:', 'bdthemes-element-pack' ); ?> </span>

					<?php
					if ( intval( $post_limit ) < '32' ) {
						echo wp_kses_post( $no_icon );
						echo '<span class="label2" title="Min: 32M Recommended" bdt-tooltip>Currently: ' . wp_kses_post( $post_limit ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">Currently: ' . wp_kses_post( $post_limit ) . '</span>';
					}
					?>
				</div>
			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'Uploads folder writable:', 'bdthemes-element-pack' ); ?></span>

					<?php
					if ( ! is_writable( $upload_path ) ) {
						echo wp_kses_post( $no_icon );
					} else {
						echo wp_kses_post( $yes_icon );
					}
					?>
				</div>

			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'MultiSite:', 'bdthemes-element-pack' ); ?></span>

					<?php
					if ( $environment['wp_multisite'] ) {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">' . esc_html__( 'MultiSite', 'bdthemes-element-pack' ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">' . esc_html__( 'No MultiSite', 'bdthemes-element-pack' ) . '</span>';
					}
					?>
				</div>
			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'GZip Enabled:', 'bdthemes-element-pack' ); ?></span>

					<?php
					if ( $environment['gzip_enabled'] ) {
						echo wp_kses_post( $yes_icon );
					} else {
						echo wp_kses_post( $no_icon );
					}
					?>
				</div>

			</li>

			<li>
				<div>
					<span class="label1"><?php esc_html_e( 'Debug Mode:', 'bdthemes-element-pack' ); ?></span>
					<?php
					if ( $environment['wp_debug_mode'] ) {
						echo wp_kses_post( $no_icon );
						echo '<span class="label2">' . esc_html__( 'Currently Turned On', 'bdthemes-element-pack' ) . '</span>';
					} else {
						echo wp_kses_post( $yes_icon );
						echo '<span class="label2">' . esc_html__( 'Currently Turned Off', 'bdthemes-element-pack' ) . '</span>';
					}
					?>
				</div>

			</li>

		</ul>

		<div class="bdt-admin-alert">
			<strong><?php esc_html_e( 'Note:', 'bdthemes-element-pack' ); ?></strong>
			<?php
			printf(
				esc_html__( 'If you have multiple addons like %s so you may need to allocate additional memory for other addons as well.', 'bdthemes-element-pack' ),
				'<b>Element Pack</b>'
			);
			?>
		</div>

		<?php
	}

	/**
	 * Display Plugin Page
	 *
	 * @access public
	 * @return void
	 */

	public function plugin_page() {

		?>

		<div class="wrap element-pack-dashboard">
			<h1><?php echo esc_html( BDTEP_TITLE ) . esc_html__( ' Settings', 'bdthemes-element-pack' ) ?></h1>

			<?php $this->settings_api->show_navigation(); ?>


			<div class="bdt-switcher bdt-tab-container bdt-container-xlarge">
				<div id="element_pack_welcome_page" class="ep-option-page group">
					<?php $this->element_pack_welcome(); ?>

					<?php if ( ! defined( 'BDTEP_WL' ) || false == self::license_wl_status() ) {
						$this->footer_info();
					} ?>
				</div>

				<?php
				$this->settings_api->show_forms();
				?>

				<!-- Wincher Implementation -->
				<div id="element_pack_seo_performance_page" class="ep-option-page group">
					<?php
					apply_filters( 'bdt_wincher_seo_performance', '' );

					if ( ! defined( 'BDTEP_WL' ) || false == self::license_wl_status() ) {
						$this->footer_info();
					}
					?>
				</div>
				<!-- /Wincher Implementation -->

				<div id="element_pack_license_settings_page" class="ep-option-page group">

					<?php $this->license_page(); ?>

					<?php if ( ! defined( 'BDTEP_WL' ) || false == self::license_wl_status() ) {
						$this->footer_info();
					} ?>
				</div>
			</div>

		</div>

		<?php

		$this->script();

		?>

		<?php
	}

	/**
	 * License Activate Action
	 * @access public
	 */

	public function action_activate_license() {
		check_admin_referer( 'el-license' );

		$licenseKey   = ! empty( $_POST['element_pack_license_key'] ) ? sanitize_text_field( $_POST['element_pack_license_key'] ) : "";
		$licenseEmail = ! empty( $_POST['element_pack_license_email'] ) ? wp_unslash( $_POST['element_pack_license_email'] ) : "";

		update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), $licenseKey );
		update_option( "element_pack_license_email", $licenseEmail );

		wp_safe_redirect( admin_url( 'admin.php?page=' . 'element_pack_options#element_pack_license_settings' ) );
	}

	/**
	 * License Deactivate Action
	 * @access public
	 */

	public function action_deactivate_license() {

		check_admin_referer( 'el-license' );
		if ( Element_Pack_Base::remove_license_key( BDTEP__FILE__, $message ) ) {
			update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), "" );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . 'element_pack_options#element_pack_license_settings' ) );
	}

	/**
	 * Display License Activated
	 *
	 * @access public
	 * @return void
	 */

	public function license_activated() {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="element_pack_deactivate_license" />
			<div class="el-license-container bdt-card bdt-card-body">


				<h3 class="el-license-title"><span class="dashicons dashicons-admin-network"></span>
					<?php esc_html_e( "Element Pack License Information", 'bdthemes-element-pack' ); ?>
				</h3>

				<ul class="element-pack-license-info bdt-list bdt-list-divider">
					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'Status', 'bdthemes-element-pack' ); ?>
							</span>

							<?php if ( Element_Pack_Base::get_register_info()->is_valid ) : ?>
								<span class="license-valid"><?php esc_html_e( 'Valid License', 'bdthemes-element-pack' ); ?></span>
							<?php else : ?>
								<span
									class="license-valid"><?php esc_html_e( 'Invalid License', 'bdthemes-element-pack' ); ?></span>
							<?php endif; ?>
						</div>
					</li>

					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'License Type', 'bdthemes-element-pack' ); ?>
							</span>
							<?php echo esc_html( Element_Pack_Base::get_register_info()->license_title ); ?>
						</div>
					</li>

					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'License Expired on', 'bdthemes-element-pack' ); ?>
							</span>
							<?php echo esc_html( Element_Pack_Base::get_register_info()->expire_date ); ?>
						</div>
					</li>

					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'Support Expired on', 'bdthemes-element-pack' ); ?>
							</span>
							<?php echo esc_html( Element_Pack_Base::get_register_info()->support_end ); ?>
						</div>
					</li>

					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'License Email', 'bdthemes-element-pack' ); ?>
							</span>
							<?php echo esc_html( self::get_license_email() ); ?>
						</div>
					</li>

					<li>
						<div>
							<span class="license-info-title">
								<?php esc_html_e( 'Your License Key', 'bdthemes-element-pack' ); ?>
							</span>
							<span class="license-key">
								<?php echo esc_html( substr( Element_Pack_Base::get_register_info()->license_key, 0, 9 ) . "XXXXXXXX-XXXXXXXX" . substr( Element_Pack_Base::get_register_info()->license_key, -9 ) ); ?>
							</span>
						</div>
					</li>
				</ul>

				<div class="el-license-active-btn">
					<?php wp_nonce_field( 'el-license' ); ?>
					<?php submit_button( esc_html__( 'Deactivate License', 'bdthemes-element-pack' ) ); ?>
				</div>
			</div>
		</form>
		<?php
	}

	/**
	 * Display License Form
	 *
	 * @access public
	 * @return void
	 */

	public function license_form() {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="element_pack_activate_license" />
			<div class="el-license-container bdt-card bdt-card-body">

				<?php
				if ( ! empty( $this->showMessage ) && ! empty( $this->licenseMessage ) ) {
					?>
					<div class="notice notice-error is-dismissible">
						<p>
							<?php echo wp_kses_post( $this->licenseMessage ); ?>
						</p>
					</div>
					<?php
				}
				?>

				<h3 class="bdt-text-large">
					<strong>
						<?php esc_html_e( 'Enter your license key here, to activate Element Pack Pro, and get full feature updates and premium support.', 'bdthemes-element-pack' ); ?>
					</strong>
				</h3>

				<ol class="bdt-text-default">
					<li>
						<?php
						echo wp_kses_post( sprintf( 'Log in to your <a href="%1s" target="_blank">bdthemes fastspring</a> or <a href="%2s" target="_blank">envato</a> account to get your license key.', esc_url( 'https://account.bdthemes.com/' ), esc_url( 'https://codecanyon.net/downloads' ) ) );
						?>
					</li>
					<li>
						<?php echo wp_kses_post( sprintf( 'If you don\'t yet have a license key, <a href="%s" target="_blank">get Element Pack Pro now</a>.', esc_url( 'https://elementpack.pro/pricing/' ) ) ); ?>
					</li>
					<li>
						<?php esc_html_e( 'Copy the license key from your account and paste it below for work element pack properly.', 'bdthemes-element-pack' ); ?>
					</li>
				</ol>

				<div class="bdt-ep-license-field">
					<label for="element_pack_license_email">
						<?php esc_html_e( 'License Email', 'bdthemes-element-pack' ); ?>
						<input type="text" class="regular-text code" name="element_pack_license_email" size="50"
							placeholder="example@email.com" required="required">
					</label>
				</div>

				<div class="bdt-ep-license-field">
					<label for="element_pack_license_key"><?php esc_html_e( 'License Code', 'bdthemes-element-pack' ); ?>
						<input type="text" class="regular-text code" name="element_pack_license_key" size="50"
							placeholder="xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx" required="required">
					</label>
				</div>


				<div class="el-license-active-btn">
					<?php wp_nonce_field( 'el-license' ); ?>
					<?php submit_button( esc_html__( 'Activate License', 'bdthemes-element-pack' ) ); ?>
				</div>
			</div>
		</form>
		<?php
	}

	/**
	 * Tabbable JavaScript codes & Initiate Color Picker
	 *
	 * This code uses localstorage for displaying active tabs
	 */
	public function script() {
		?>
		<script>
			jQuery(document).ready(function () {
				jQuery('.ep-no-result').removeClass('bdt-animation-shake');
			});

			function filterSearch(e) {
				var parentID = '#' + jQuery(e).data('id');
				var search = jQuery(parentID).find('.bdt-search-input').val().toLowerCase();


				jQuery(".ep-options .ep-option-item").filter(function () {
					jQuery(this).toggle(jQuery(this).attr('data-widget-name').toLowerCase().indexOf(search) > -1)
				});

				if (!search) {
					jQuery(parentID).find('.bdt-search-input').attr('bdt-filter-control', "");
					jQuery(parentID).find('.ep-widget-all').trigger('click');
				} else {
					// if (search.length < 3) {
					//     return;
					// }
					jQuery(parentID).find('.bdt-search-input').attr('bdt-filter-control', "filter: [data-widget-name*='" + search + "']");
					jQuery(parentID).find('.bdt-search-input').removeClass('bdt-active');
				}
				jQuery(parentID).find('.bdt-search-input').trigger('click');

			}


			jQuery('.ep-options-parent').each(function (e, item) {
				var eachItem = '#' + jQuery(item).attr('id');
				jQuery(eachItem).on("beforeFilter", function () {
					jQuery(eachItem).find('.ep-no-result').removeClass('bdt-animation-shake');
				});

				jQuery(eachItem).on("afterFilter", function () {
					var isElementVisible = false;
					var i = 0;

					if (jQuery(eachItem).closest(".ep-options-parent").eq(i).is(":visible")) { } else {
						isElementVisible = true;
					}

					while (!isElementVisible && i < jQuery(eachItem).find(".ep-option-item").length) {
						if (jQuery(eachItem).find(".ep-option-item").eq(i).is(":visible")) {
							isElementVisible = true;
						}
						i++;
					}

					if (isElementVisible === false) {
						jQuery(eachItem).find('.ep-no-result').addClass('bdt-animation-shake');
					}

				});
			});


			jQuery('.ep-widget-filter-nav li a').on('click', function (e) {
				jQuery(this).closest('.bdt-widget-filter-wrapper').find('.bdt-search-input').val('');
				jQuery(this).closest('.bdt-widget-filter-wrapper').find('.bdt-search-input').val('').attr('bdt-filter-control', '');
			});


			jQuery(document).ready(function ($) {
				'use strict';

				function hashHandler() {
					var $tab = jQuery('.element-pack-dashboard .bdt-tab');
					if (window.location.hash) {
						var hash = window.location.hash.substring(1);
						bdtUIkit.tab($tab).show(jQuery('#bdt-' + hash).data('tab-index'));
					}
				}

				jQuery(window).on('load', function () {
					hashHandler();
				});

				window.addEventListener("hashchange", hashHandler, true);

				jQuery('.toplevel_page_element_pack_options > ul > li > a ').on('click', function (event) {
					jQuery(this).parent().siblings().removeClass('current');
					jQuery(this).parent().addClass('current');
				});

				jQuery('#element_pack_active_modules_page a.ep-active-all-widget').on('click', function (e) {
					e.preventDefault();

					jQuery('#element_pack_active_modules_page .ep-option-item:not(.ep-pro-inactive) .checkbox:visible').each(function () {
						jQuery(this).attr('checked', 'checked').prop("checked", true);
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-deactive-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_active_modules_page a.ep-deactive-all-widget').on('click', function (e) {
					e.preventDefault();

					jQuery('#element_pack_active_modules_page .checkbox:visible').each(function () {
						jQuery(this).removeAttr('checked');
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-active-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_third_party_widget_page a.ep-active-all-widget').on('click', function () {

					jQuery('#element_pack_third_party_widget_page .ep-option-item:not(.ep-pro-inactive) .checkbox:visible').each(function () {
						jQuery(this).attr('checked', 'checked').prop("checked", true);
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-deactive-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_third_party_widget_page a.ep-deactive-all-widget').on('click', function () {

					jQuery('#element_pack_third_party_widget_page .checkbox:visible').each(function () {
						jQuery(this).removeAttr('checked');
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-active-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_elementor_extend_page a.ep-active-all-widget').on('click', function () {

					jQuery('#element_pack_elementor_extend_page .ep-option-item:not(.ep-pro-inactive) .checkbox:visible').each(function () {
						jQuery(this).attr('checked', 'checked').prop("checked", true);
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-deactive-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_elementor_extend_page a.ep-deactive-all-widget').on('click', function () {

					jQuery('#element_pack_elementor_extend_page .checkbox:visible').each(function () {
						jQuery(this).removeAttr('checked');
					});

					jQuery(this).addClass('bdt-active');
					jQuery('a.ep-active-all-widget').removeClass('bdt-active');
				});

				jQuery('#element_pack_active_modules_page, #element_pack_third_party_widget_page, #element_pack_elementor_extend_page, #element_pack_other_settings_page').find('.ep-pro-inactive .checkbox').each(function () {
					jQuery(this).removeAttr('checked');
					jQuery(this).attr("disabled", true);
				});

				jQuery('form.settings-save').submit(function (event) {
					event.preventDefault();

					bdtUIkit.notification({
						message: '<div bdt-spinner></div> <?php esc_html_e( 'Please wait, Saving settings...', 'bdthemes-element-pack' ) ?>',
						timeout: false
					});

					jQuery(this).ajaxSubmit({
						success: function () {
							bdtUIkit.notification.closeAll();
							bdtUIkit.notification({
								message: '<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Settings Saved Successfully.', 'bdthemes-element-pack' ) ?>',
								status: 'primary'
							});
						},
						error: function (data) {
							bdtUIkit.notification.closeAll();
							bdtUIkit.notification({
								message: '<span bdt-icon=\'icon: warning\'></span> <?php esc_html_e( 'Unknown error, make sure access is correct!', 'bdthemes-element-pack' ) ?>',
								status: 'warning'
							});
						}
					});

					return false;
				});

			});
		</script>
		<?php
	}

	/**
	 * Display Footer
	 *
	 * @access public
	 * @return void
	 */

	public function footer_info() {
		?>
		<div class="element-pack-footer-info bdt-margin-medium-top">
			<div class="bdt-grid ">
				<div class="bdt-width-auto@s ep-setting-save-btn">
				</div>
				<div class="bdt-width-expand@s bdt-text-right">
					<p class="">
						<?php
						echo sprintf(
							__( 'Element Pack Pro plugin made with love by <a target="_blank" href="%1$s">BdThemes</a> Team.<br>All rights reserved by <a target="_blank" href="%1$s">BdThemes.com</a>.', 'bdthemes-element-pack' ),
							esc_url( 'https://bdthemes.com' )
						);
						?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * License Active Error
	 *
	 * @access public
	 */

	public function license_activate_error_notice() {
		Notices::add_notice(
			[ 
				'id'               => 'license-error',
				'type'             => 'error',
				'dismissible'      => true,
				'dismissible-time' => 43200,
				'title'            => esc_html__( 'Sorry, Element Pack is not activated!', 'bdthemes-element-pack' ),
				'message'          => $this->licenseMessage,
			]
		);
	}

	/**
	 * License Active Notice
	 *
	 * @access public
	 */

	public function license_activate_notice() {
		Notices::add_notice(
			[ 
				'id'               => 'license-issue',
				'type'             => 'error',
				'dismissible'      => true,
				'dismissible-time' => HOUR_IN_SECONDS * 72,
				'html_message'     => $this->license_active_notice_message(),
			]
		);
	}

	public function license_active_notice_message() {
		$plugin_icon  = BDTEP_ASSETS_URL . 'images/logo.svg';
		$plugin_title = __( 'Element Pack Pro', 'bdthemes-element-pack' );
		$plugin_msg   = __( 'Thank you for purchase Element Pack. Please activate your license to get feature updates, premium support. Don\'t have Element Pack license? Purchase and download your license copy from here.', 'bdthemes-element-pack' );
		ob_start();
		?>
		<div class="bdt-license-notice-global element_pack_pro">
			<?php if ( ! empty( $plugin_icon ) ) : ?>
				<div class="bdt-license-notice-logo">
					<img src="<?php echo esc_url( $plugin_icon ); ?>" alt="icon">
				</div>
			<?php endif; ?>
			<div class="bdt-license-notice-content">
				<h3>
					<?php printf( wp_kses_post( $plugin_title ) ); ?>
				</h3>
				<p>
					<?php printf( wp_kses_post( $plugin_msg ) ); ?>
				</p>
				<div class="bdt-license-notice-button-wrap">
					<a href="<?php echo esc_url( self::get_url() ); ?>#element_pack_license_settings"
						class="bdt-button bdt-button-allow">
						<?php esc_html_e( 'Activate License', 'bdthemes-element-pack' ); ?>
					</a>
					<a href="https://elementpack.pro/" target="_blank" class="bdt-button bdt-button-skip">
						<?php esc_html_e( 'Get License', 'bdthemes-element-pack' ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 *
	 * Check mini-Cart of Elementor Activated or Not
	 * It's better to not use multiple mini-Cart on the same time.
	 * Transient Expire on 15 days
	 *
	 * @access public
	 */

	public function el_use_mini_cart() {
		Notices::add_notice(
			[ 
				'id'               => 'ep-el-use-mini-cart',
				'type'             => 'warning',
				'dismissible'      => true,
				'dismissible-time' => MONTH_IN_SECONDS / 2,
				'title'            => esc_html__( 'Oops, Possibilities to get errors', 'bdthemes-element-pack' ),
				'message'          => __( 'We can see you activated the <strong>Mini-Cart</strong> of Elementor Pro and also Element Pack Pro. We will recommend you to choose one of them, otherwise you will get conflict. Thank you.', 'bdthemes-element-pack' ),
			]
		);
	}

	/**
	 * Get all the pages
	 *
	 * @return array page names with key value pairs
	 */
	public function get_pages() {
		$pages         = get_pages();
		$pages_options = [];
		if ( $pages ) {
			foreach ( $pages as $page ) {
				$pages_options[ $page->ID ] = $page->post_title;
			}
		}

		return $pages_options;
	}
}

new ElementPack_Admin_Settings();
