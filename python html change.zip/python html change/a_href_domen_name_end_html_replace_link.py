import os
from urllib.parse import urlparse
from bs4 import BeautifulSoup

def get_relative_path(from_file_path, to_target_file):
    from_dir = os.path.dirname(from_file_path)
    rel_path = os.path.relpath(to_target_file, from_dir)
    return rel_path.replace("\\", "/")

def normalize_href(href, domain):
    if domain in href:
        href = href[href.find(domain):]
        href = "https://" + href
    href = href.replace("index.html/", "")
    while "index.html/index.html" in href:
        href = href.replace("index.html/index.html", "index.html")
    return href

def clean_links(file_path, shop_folder, www_folder):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html5lib')
        changed = False

        for link in soup.find_all('a', href=True):
            href = link['href']
            if "shop.swimuniversity.com" in href or "www.swimuniversity.com" in href:

                if "shop.swimuniversity.com" in href:
                    fixed_href = normalize_href(href, "shop.swimuniversity.com")
                    base_folder = shop_folder
                else:
                    fixed_href = normalize_href(href, "www.swimuniversity.com")
                    base_folder = www_folder

                parsed = urlparse(fixed_href)
                path_parts = parsed.path.strip('/').split('/')
                if path_parts and not path_parts[-1].endswith(".html"):
                    path_parts.append("index.html")

                target_file_path = os.path.join(base_folder, *path_parts)
                if not target_file_path.endswith(".html"):
                    target_file_path = os.path.join(target_file_path, "index.html")

                relative_path = get_relative_path(file_path, target_file_path)
                link['href'] = relative_path
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Yangilandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def process_all_files(root_dir):
    www_folder = os.path.join(root_dir, "www.swimuniversity.com")
    shop_folder = os.path.join(root_dir, "shop.swimuniversity.com")

    for root, _, files in os.walk(root_dir):
        for file in files:
            if file.lower().endswith('.html'):
                full_path = os.path.join(root, file)
                clean_links(full_path, shop_folder, www_folder)

# Ushbu qatorni to‘g‘ri yo‘l bilan almashtiring
your_site_folder = r"C:/Users/WebBro/Desktop/TEST_COPY_SITE/"
process_all_files(your_site_folder)
