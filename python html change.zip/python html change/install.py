
# PIP bilan kerakli kutubxonani o'rnating (bir marta):

# 1: pip install beautifulsoup4

# 2: pip install html5lib