import os
from urllib.parse import urlparse, urlunparse
from bs4 import BeautifulSoup

def get_relative_path(from_path, to_path):
    rel_path = os.path.relpath(to_path, os.path.dirname(from_path))
    return rel_path.replace("\\", "/")

def clean_shop_links(file_path, shop_folder):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html5lib')
        changed = False

        for link in soup.find_all('a', href=True):
            href = link['href']
            if "shop.swimuniversity.com" in href:
                parsed = urlparse(href)
                path_parts = parsed.path.strip('/').split('/')
                query = parsed.query

                # Har qanday query bo‘lsa olib tashlanadi va index.html qo‘shiladi
                if path_parts:
                    target_file_path = os.path.join(shop_folder, *path_parts, "index.html")
                else:
                    target_file_path = os.path.join(shop_folder, "index.html")

                relative_path = get_relative_path(file_path, target_file_path)
                link['href'] = relative_path
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Linklar yangilandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def process_all_files(root_dir):
    www_folder = os.path.join(root_dir, "www.swimuniversity.com")
    shop_folder = os.path.join(root_dir, "shop.swimuniversity.com")

    for root, _, files in os.walk(www_folder):
        for file in files:
            if file.lower().endswith('.html'):
                full_path = os.path.join(root, file)
                clean_shop_links(full_path, shop_folder)

# Asosiy sayt papkasi
your_site_folder = "C:/Users/WebBro/Desktop/TEST_COPY_SITE/"
process_all_files(your_site_folder)
