import os
from bs4 import BeautifulSoup

def is_gtag_related(tag):
    """Check if script/noscript tag is related to Google Tag or Analytics."""
    if tag.name not in ['script', 'noscript']:
        return False
    
    # Tekshiriladigan atributlar
    for attr in ['src', 'data-rocket-src', 'id']:
        val = tag.get(attr, '')
        if 'googletagmanager.com' in val or 'gtag' in val or 'analytics' in val:
            return True

    # Ichki matn (inline script)
    content = tag.string or tag.decode_contents()
    if content:
        lowered = content.lower()
        if 'googletagmanager.com' in lowered or 'gtag(' in lowered or 'analytics' in lowered:
            return True

    return False

def clean_gtag_from_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            html = f.read()

        soup = BeautifulSoup(html, 'html.parser')
        original = str(soup)

        # O‘chirish uchun mos keladigan taglar
        for tag in soup.find_all(['script', 'noscript']):
            if is_gtag_related(tag):
                tag.decompose()

        cleaned = str(soup)
        if cleaned != original:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(cleaned)
            print(f"[✅ Clean] {file_path}")
        else:
            print(f"[-- No Edit] {file_path}")

    except Exception as e:
        print(f"[XATO] {file_path}: {e}")

def process_all_html_files(root_folder):
    for root, _, files in os.walk(root_folder):
        for file in files:
            if file.lower().endswith(".html"):
                full_path = os.path.join(root, file)
                clean_gtag_from_file(full_path)

# BU YERGA HTML FAYLLARINGIZ FOLDER YO‘LINI YAZING:
folder_path = r"C:/Users/WebBro/Desktop/google_tag/"
process_all_html_files(folder_path)
