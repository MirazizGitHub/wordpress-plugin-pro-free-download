import os
import re
from bs4 import BeautifulSoup

def fix_shop_links(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html5lib')
        changed = False

        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href']

            if "shop.swimuniversity.com" in href:
                # 1️⃣ Oldidagi nisbiy pathlarni olib tashlash (../../../...)
                href = re.sub(r'(\.\./)+(?=shop\.swimuniversity\.com)', '', href)

                # 2️⃣ index.html/index.html/index.html ni bitta qilish
                href = re.sub(r'(index\.html/)+', '', href)
                href = re.sub(r'(index\.html)+$', 'index.html', href)

                # 3️⃣ https:// bilan boshlanmasa, qo‘shish
                if not href.startswith("http"):
                    href = re.sub(r'^(shop\.swimuniversity\.com)', r'https://\1', href)

                a_tag['href'] = href
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Tahrirlandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def process_all_files(root_dir):
    for root, _, files in os.walk(root_dir):
        for file in files:
            if file.lower().endswith('.html'):
                full_path = os.path.join(root, file)
                fix_shop_links(full_path)

# 🔁 Barcha fayllar uchun
root_folder = r"C:/Users/WebBro/Desktop/TEST_COPY_SITE/"
process_all_files(root_folder)
