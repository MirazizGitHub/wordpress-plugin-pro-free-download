import os
from bs4 import BeautifulSoup

def get_relative_path(from_path, to_path):
    # Windows yo'llarini HTML nisbiy yo'lga o'girish
    rel_path = os.path.relpath(to_path, os.path.dirname(from_path))
    return rel_path.replace("\\", "/")  # Windows slashni tuzatamiz

def clean_links_in_html(file_path, shop_folder):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html5lib')
        changed = False

        for link in soup.find_all('a', href=True):
            href = link['href']
            if href.startswith("https://shop.swimuniversity.com"):
                path_inside_shop = href.replace("https://shop.swimuniversity.com", "")
                target_file_path = os.path.normpath(os.path.join(shop_folder, path_inside_shop.strip("/")))

                # Masalan: '../../products/pool-care-app'
                relative_path = get_relative_path(file_path, target_file_path)
                link['href'] = relative_path
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Linklar tozalandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def clean_all_html_files(root_dir):
    www_folder = os.path.join(root_dir, "www.swimuniversity.com")
    shop_folder = os.path.join(root_dir, "shop.swimuniversity.com")

    for root, _, files in os.walk(www_folder):
        for file in files:
            if file.lower().endswith(".html"):
                full_path = os.path.join(root, file)
                clean_links_in_html(full_path, shop_folder)

# === Sizning asosiy sayt papkangiz:
your_site_folder = r"C:/Users/WebBro/Desktop/TEST_COPY_SITE/"
clean_all_html_files(your_site_folder)
