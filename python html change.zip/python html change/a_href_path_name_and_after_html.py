
import os
from urllib.parse import urlparse
from bs4 import BeautifulSoup

def get_relative_path(from_file_path, to_target_file):
    from_dir = os.path.dirname(from_file_path)
    rel_path = os.path.relpath(to_target_file, from_dir)
    return rel_path.replace("\\", "/")

def normalize_shop_href(href):
    # Avval absolute URL holatiga keltiramiz
    if "shop.swimuniversity.com" in href:
        href = href[href.find("shop.swimuniversity.com"):]
        href = "https://" + href

    # Ko‘payib ketgan `index.html/index.html/...` holatni tozalaymiz
    href = href.replace("index.html/", "")
    while "index.html/index.html" in href:
        href = href.replace("index.html/index.html", "index.html")

    return href

def clean_shop_links(file_path, shop_folder):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        soup = BeautifulSoup(content, 'html5lib')
        changed = False

        for link in soup.find_all('a', href=True):
            href = link['href']

            if "shop.swimuniversity.com" in href or "shop.swimuniversity.com" in normalize_shop_href(href):
                fixed_href = normalize_shop_href(href)
                parsed = urlparse(fixed_href)
                path_parts = parsed.path.strip('/').split('/')

                if path_parts and path_parts[-1] == '':
                    path_parts.pop()

                if path_parts and not path_parts[-1].endswith(".html"):
                    path_parts.append("index.html")

                target_file_path = os.path.join(shop_folder, *path_parts)
                if not target_file_path.endswith(".html"):
                    target_file_path = os.path.join(target_file_path, "index.html")

                relative_path = get_relative_path(file_path, target_file_path)
                link['href'] = relative_path
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Linklar yangilandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def process_all_files(root_dir):
    www_folder = os.path.join(root_dir, "www.swimuniversity.com")
    shop_folder = os.path.join(root_dir, "shop.swimuniversity.com")

    for root, _, files in os.walk(www_folder):
        for file in files:
            if file.lower().endswith('.html'):
                full_path = os.path.join(root, file)
                clean_shop_links(full_path, shop_folder)

# Foydalanuvchi sayti joylashgan papka
your_site_folder = r"C:/Users/WebBro/Desktop/test_folder/"
process_all_files(your_site_folder)
