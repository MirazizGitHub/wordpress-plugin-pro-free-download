import os
from bs4 import BeautifulSoup
import warnings
from bs4 import XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

def is_allowed_meta(tag):
    if tag.has_attr('charset'):
        return True
    if tag.has_attr('name') and tag['name'].strip().lower() == 'viewport':
        return True
    return False

def clean_head_section(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            if not content.strip():
                print(f"[⚠️ Bo'sh fayl] {file_path}")
                return

            # ESKI html.parser o‘rniga HTML5LIB
            soup = BeautifulSoup(content, 'html5lib')

        head = soup.find('head')
        if not head:
            print(f"[⚠️ <head> topilmadi] {file_path}")
            return

        changed = False
        for meta_tag in head.find_all('meta'):
            if not is_allowed_meta(meta_tag):
                meta_tag.decompose()
                changed = True

        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(str(soup))
            print(f"[✅ Tozalandi] {file_path}")
        else:
            print(f"[-- O'zgarish yo'q] {file_path}")

    except Exception as e:
        print(f"[Xatolik] {file_path}: {e}")

def clean_all_html_files(root_dir):
    for root, _, files in os.walk(root_dir):
        for file in files:
            if file.lower().endswith('.html'):
                full_path = os.path.join(root, file)
                clean_head_section(full_path)

# Sizning papkangiz yo‘li:
your_site_folder = r"C:/Users/WebBro/Desktop/TEST_COPY_SITE/"
clean_all_html_files(your_site_folder)
